package schach.daten;

public class D_Figur extends D{
	public D_Figur(){
		addString("typ","");
		addBool("isWeiss",true);
		addString("position","");
		addBool("bereitsBewegt",false);
	}
}
