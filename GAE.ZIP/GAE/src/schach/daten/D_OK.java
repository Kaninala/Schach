package schach.daten;

public class D_OK extends D {
	
	public D_OK(){
	}
	
	public D_OK(String meldung){
		addString("meldung",meldung);
	}
}
