package schach.daten;

public class D_ZugHistorie extends D{
	public D_ZugHistorie(){
		addString("zug","");
	}
}
