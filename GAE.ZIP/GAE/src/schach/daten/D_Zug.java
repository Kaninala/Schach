package schach.daten;

public class D_Zug extends D{
	public D_Zug(){
		addString("von","");
		addString("nach","");
		addString("status","");
		addString("bemerkung","");
	}
}
