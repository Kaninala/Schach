package schach.daten;

public class D_Spiel extends D {
	public D_Spiel(){
		addInt("anzahlZuege",0);
		addString("bemerkung","");
		addString("status","");
	}
}
