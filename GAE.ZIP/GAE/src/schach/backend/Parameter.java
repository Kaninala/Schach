package schach.backend;

public class Parameter {
	public static final int maxAnzahlSpiele=2048;
	public static final String pfadKlassenDaten="schach.daten.";
}
